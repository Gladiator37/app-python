from flask import Blueprint, jsonify, request, session
from werkzeug.security import generate_password_hash, check_password_hash
from models.db import get_db_connection

users_blueprint = Blueprint('users', __name__)

# Endpoint para registrar usuarios
@users_blueprint.route('/register', methods=['POST'])
def register_user():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')

    if not username or not password:
        return jsonify({"error": "Faltan datos obligatorios"}), 400

    connection = get_db_connection()
    if connection:
        try:
            with connection.cursor() as cursor:
                cursor.execute(
                    "INSERT INTO usuarios (username, password) VALUES (%s, %s)",
                    (username, generate_password_hash(password))
                )
                connection.commit()
            connection.close()
            return jsonify({"message": f"Usuario {username} registrado exitosamente"}), 201
        except Exception as e:
            connection.close()
            return jsonify({"error": f"Error al registrar usuario: {e}"}), 500
    return jsonify({"error": "Error al conectar con la base de datos"}), 500


# Endpoint para el login de usuarios
@users_blueprint.route('/api/login', methods=['POST'])
def login_user():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')

    if not username or not password:
        return jsonify({"error": "Faltan datos obligatorios"}), 400

    connection = get_db_connection()
    if connection:
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT * FROM usuarios WHERE username = %s", (username,))
                user = cursor.fetchone()
            connection.close()

            if user and check_password_hash(user['password'], password):
                session['username'] = username
                return jsonify({"message": "Inicio de sesión exitoso"}), 200
            return jsonify({"error": "Credenciales inválidas"}), 401
        except Exception as e:
            connection.close()
            return jsonify({"error": f"Error al autenticar usuario: {e}"}), 500
    return jsonify({"error": "Error al conectar con la base de datos"}), 500


# Endpoint para cerrar sesión
@users_blueprint.route('/logout', methods=['GET'])
def logout_user():
    session.clear()
    return jsonify({"message": "Sesión cerrada"}), 200
